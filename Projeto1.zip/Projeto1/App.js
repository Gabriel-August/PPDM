//import React, { use, useState } from "react"; // cria componentes e controla os status
//import { View, Text, StyleSheet } from "react-native"; // View conteneiner, Text todo texto que aparece na tela, StyleSheet

import React, { useState } from "react";
import { View, Text, StyleSheet, Button, TextInput } from "react-native";

function App() {
  // States for each input field
  const [nome, setNome] = useState("");
  const [sobrenome, setSobrenome] = useState("");
  const [idade, setIdade] = useState("");

  // A single state to hold the final message to be displayed
  const [mensagemExibida, setMensagemExibida] = useState("");

  // A single function to create and set the message
  const mostrarInformacoes = () => {
    // We check if all fields are filled before creating the message
    if (nome && sobrenome && idade) {
      setMensagemExibida(`Olá, ${nome} ${sobrenome}! Você tem ${idade} anos.`);
    } else {
      setMensagemExibida("Por favor, preencha todos os campos.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Digite seu nome:</Text>
      <TextInput
        style={styles.input}
        placeholder="Seu nome aqui"
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>Digite seu sobrenome:</Text>
      <TextInput
        style={styles.input}
        placeholder="Seu sobrenome aqui"
        value={sobrenome}
        onChangeText={setSobrenome}
      />

      <Text style={styles.label}>Digite sua idade:</Text>
      <TextInput
        style={styles.input}
        placeholder="Sua idade aqui"
        value={idade}
        onChangeText={setIdade}
        keyboardType="numeric" // Good practice for number inputs
      />

      {/* The button now calls the single, clear function */}
      <Button title="Mostrar Informações" onPress={mostrarInformacoes} />

      {/* The Text component displays the final message or a default prompt */}
      <Text style={styles.nomeText}>
        {mensagemExibida || "Clique no botão para ver as informações."}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
    backgroundColor: "#fff",
  },
  label: {
    fontSize: 20,
    marginBottom: 8,
  },
  input: {
    height: 50,
    borderColor: "#888",
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    fontSize: 18,
    marginBottom: 20,
  },
  nomeText: {
    fontSize: 20,
    color: "#333",
    marginTop: 20,
    fontWeight: "bold",
    textAlign: "center", // Centered text looks better
  },
});

export default App;
