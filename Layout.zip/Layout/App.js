import React from "react";
import { StyleSheet, ScrollView, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";

import ConfigScreens from "./src/screens/Configscreesn";
import HomeScreen from "./src/screens/Homescreesn";
import PerfilScreens from "./src/screens/PerfilScreesn";

const Drawer = createDrawerNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="Home" component={HomeScreen} options={{title:'Home'}} />
        <Drawer.Screen name="Perfil" component={PerfilScreens} options={{title:'Perfil'}} />
        <Drawer.Screen name="Configurações" component={ConfigScreens} options={{title:'Config'}} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  scrollContainer: {
    paddingBottom: 20, // optional
  },
});
