import React, { useState, useEffect } from "react";
// ...existing code...
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Platform,
} from "react-native";
// remove top-level react-native-maps import (causes web bundling errors)
// import MapView, { Marker, PROVIDER_GOOGLE } from "react-native-maps";
import * as Location from "expo-location";

export default function Mapa() {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);

  // lazy require react-native-maps only on native platforms
  let MapViewComp = null;
  let MarkerComp = null;
  let MAPS_PROVIDER = null;
  if (Platform.OS !== "web") {
    const RNMaps = require("react-native-maps");
    MapViewComp = RNMaps.default || RNMaps.MapView || RNMaps;
    MarkerComp = RNMaps.Marker || RNMaps.default?.Marker;
    MAPS_PROVIDER = RNMaps.PROVIDER_GOOGLE || null;
  }

  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== "granted") {
          setErrorMsg("Permissão de localização negada.");
          return;
        }
        const pos = await Location.getCurrentPositionAsync({});
        setLocation(pos.coords);
      } catch (e) {
        console.warn(e);
        setErrorMsg("Erro ao obter localização.");
      }
    })();
  }, []);

  useEffect(() => {
    if (errorMsg) Alert.alert("Erro", errorMsg);
  }, [errorMsg]);

  if (!location && !errorMsg) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#0000ff" />
        <Text style={styles.msg}>Buscando localização...</Text>
      </View>
    );
  }

  if (errorMsg) {
    return (
      <View style={styles.center}>
        <Text style={styles.msg}>{errorMsg}</Text>
      </View>
    );
  }

  // Web: embed Google Maps via iframe
  if (Platform.OS === "web") {
    const lat = location.latitude;
    const lng = location.longitude;
    const zoom = 15;
    const src = `https://www.google.com/maps?q=${lat},${lng}&z=${zoom}&output=embed`;

    return (
      <View style={styles.container}>
        <iframe
          title="Mapa"
          src={src}
          style={{ flex: 1, width: "100%", height: "100%", border: 0 }}
          allowFullScreen
          loading="lazy"
        />
      </View>
    );
  }

  // Native (iOS / Android): use react-native-maps (loaded above)
  return (
    <View style={styles.container}>
      <MapViewComp
        provider={MAPS_PROVIDER}
        style={styles.map}
        initialRegion={{
          latitude: location.latitude,
          longitude: location.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        }}
        showsUserLocation={true}
        showsMyLocationButton={true}
      >
        <MarkerComp
          coordinate={{
            latitude: location.latitude,
            longitude: location.longitude,
          }}
          title="Você está aqui"
        />
      </MapViewComp>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  msg: { marginTop: 8, textAlign: "center" },
  map: { ...StyleSheet.absoluteFillObject },
});
