import React, { useState, useEffect } from "react";
import { Text, View, StyleSheet, Platform } from "react-native";
import { Accelerometer } from "expo-sensors";

export default function Acelerometro() {
  const [data, setData] = useState({ x: 0, y: 0, z: 0 });
  const [erro, setErro] = useState(null);

  useEffect(() => {
    let subscription;

    if (Platform.OS === "web") {
      // --- WEB ---
      const handleMotion = (event) => {
        if (event.accelerationIncludingGravity) {
          const { x, y, z } = event.accelerationIncludingGravity;
          setData({ x: x || 0, y: y || 0, z: z || 0 });
        }
      };

      if (typeof window !== "undefined" && "DeviceMotionEvent" in window) {
        window.addEventListener("devicemotion", handleMotion);
      } else {
        setErro("Acelerômetro não suportado neste navegador.");
      }

      return () => {
        window.removeEventListener("devicemotion", handleMotion);
      };
    } else {
      // --- MOBILE (Expo) ---
      const iniciar = async () => {
        try {
          const disponivel = await Accelerometer.isAvailableAsync();
          if (!disponivel) {
            setErro("Acelerômetro não disponível neste dispositivo.");
            return;
          }

          subscription = Accelerometer.addListener((dados) => {
            setData(dados);
          });
          Accelerometer.setUpdateInterval(100);
        } catch (e) {
          setErro("Erro ao acessar o acelerômetro.");
          console.error(e);
        }
      };

      iniciar();

      return () => {
        subscription && subscription.remove();
      };
    }
  }, []);

  const { x, y, z } = data;

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Acelerômetro</Text>
      {erro ? (
        <Text style={styles.erro}>{erro}</Text>
      ) : (
        <>
          <Text style={styles.texto}>x: {x.toFixed(2)}</Text>
          <Text style={styles.texto}>y: {y.toFixed(2)}</Text>
          <Text style={styles.texto}>z: {z.toFixed(2)}</Text>
        </>
      )}
      {Platform.OS === "web" && (
        <Text style={styles.info}>
          (Executando no navegador — pode não haver sensores reais)
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  header: {
    fontSize: 30,
    marginBottom: 20,
  },
  texto: {
    fontSize: 20,
  },
  erro: {
    fontSize: 18,
    color: "red",
    marginTop: 10,
  },
  info: {
    marginTop: 20,
    fontSize: 14,
    color: "#666",
  },
});
