import "react-native-gesture-handler";
import React, { useState } from "react";
import { View, Text, StyleSheet, Animated } from "react-native";
import { PinchGestureHandler } from "react-native-gesture-handler";
import { Feather } from "@expo/vector-icons"; // Importe um ícone

export default function App() {
  const [scale] = useState(new Animated.Value(1));

  const onPinchEvent = Animated.event([{ nativeEvent: { scale: scale } }], {
    useNativeDriver: true,
  });

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gesto de Pinça (Pinch)</Text>{" "}
      <Text style={styles.subtitle}>
        Use dois dedos para ampliar ou reduzir o cartão.
      </Text>{" "}
      <PinchGestureHandler onGestureEvent={onPinchEvent}>
        {" "}
        <Animated.View
          style={[
            styles.card, // Usamos o novo estilo 'card'
            {
              transform: [{ scale }],
            },
          ]}
        >
          {/* Adicionamos um ícone para ficar mais interessante */}
          <Feather name="image" size={60} color="#1E90FF" />{" "}
        </Animated.View>{" "}
      </PinchGestureHandler>{" "}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f4f4f8", // Um fundo cinza-claro suave
  },
  title: {
    fontSize: 24,
    fontWeight: "500",
    color: "#333", // Cor de texto mais escura, não preto puro
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: "#555",
    marginBottom: 40, // Mais espaço antes do cartão
    textAlign: "center",
    paddingHorizontal: 20,
  },
  card: {
    width: 150,
    height: 150,
    backgroundColor: "#fff", // Fundo branco, como um cartão
    borderRadius: 16, // Bordas mais arredondadas
    justifyContent: "center", // Centraliza o ícone
    alignItems: "center", // Centraliza o ícone // --- Sombra para dar profundidade --- // Sombra (iOS)

    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8, // Sombra (Android)
    elevation: 5,
  },
});
