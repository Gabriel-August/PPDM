import React, { useEffect, useState, useRef } from 'react';
import { View, Text, TouchableOpacity, Alert, StyleSheet, ScrollView } from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import * as Location from 'expo-location';

export default function App() {
  const [netInfo, setNetInfo] = useState(null);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const [history, setHistory] = useState([]);

  const previousConnection = useRef(null);

  // 🔹 Solicitar permissão de localização (necessária no Android para pegar SSID)
  const requestLocationPermission = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    setPermissionGranted(status === "granted");
  };

  // 🔹 Atualizar manualmente
  const refreshStatus = async () => {
    const state = await NetInfo.fetch();
    updateState(state, true);
  };

  // 🔹 Função central para atualizar estado, histórico e alertas
  const updateState = (state, manual = false) => {
    setNetInfo(state);

    const connectionType =
      state.type === "wifi"
        ? `Wi-Fi (${state.details.ssid || "sem SSID"})`
        : state.type;

    const newEntry =
      `${new Date().toLocaleTimeString()} - ${state.isConnected ? "Conectado" : "Desconectado"} (${connectionType})`;

    setHistory(prev => [newEntry, ...prev]);

    // Alerta quando a conexão cai
    if (previousConnection.current === true && state.isConnected === false) {
      Alert.alert("Conexão perdida", "Você ficou sem internet.");
    }

    previousConnection.current = state.isConnected;
  };

  useEffect(() => {
    requestLocationPermission();

    // Escuta mudanças na rede
    const unsubscribe = NetInfo.addEventListener(state => updateState(state));

    // Buscar estado inicial
    NetInfo.fetch().then(state => updateState(state));

    return () => unsubscribe();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Monitor de Conexão Wi-Fi</Text>

      {/* 🔹 Ícone de status */}
      <View style={[
        styles.circle,
        { backgroundColor: netInfo?.isConnected ? "green" : "red" }
      ]} />

      {/* 🔹 Texto do status */}
      <Text style={styles.text}>
        Status: {netInfo?.isConnected ? "Conectado" : "Desconectado"}
      </Text>

      <Text style={styles.text}>
        Tipo: {netInfo?.type || "..."}
      </Text>

      <Text style={styles.text}>
       Rede-SSID:
        {!permissionGranted
          ? " Permissão negada"
          : netInfo?.details?.ssid || " Indisponível"}
      </Text>

      {/* 🔹 Botão "Atualizar" */}
      <TouchableOpacity style={styles.button} onPress={refreshStatus}>
        <Text style={styles.buttonText}>Atualizar status</Text>
      </TouchableOpacity>

      {/* 🔹 Histórico */}
      <Text style={styles.subtitle}>Histórico:</Text>

      <ScrollView style={styles.historyBox}>
        {history.map((item, index) => (
          <Text key={index} style={styles.historyItem}>{item}</Text>
        ))}
      </ScrollView>
    </View>
  );
}

// 🔹 Estilos
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    marginTop: 40
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    alignSelf: "center",
    marginBottom: 20
  },
  circle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignSelf: "center",
    marginBottom: 15
  },
  text: {
    fontSize: 18,
    marginBottom: 5
  },
  subtitle: {
    marginTop: 20,
    fontSize: 20,
    fontWeight: "bold"
  },
  historyBox: {
    marginTop: 10,
    padding: 10,
    backgroundColor: "#eee",
    borderRadius: 10,
    height: 200
  },
  historyItem: {
    fontSize: 14,
    marginBottom: 4
  },
  button: {
    backgroundColor: "#007bff",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 15
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold"
  }
});
