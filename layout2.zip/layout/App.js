import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, ScrollView } from "react-native";
import Header from "./src/components/Header";
import Footer from "./src/components/Footer";
import Main from "./src/components/Main";
import Menu from "./src/components/Menu";
import ConfigScreen from "./screens/ConfigScreen";
import HomeScreen from "./screens/HomeScreen";
import PerfilScreen from "./screens/PerfilScreen";
import TapGestureHandler from "./screens/TapGestureHandler";
import RotationGestureHandler from "./screens/RotationGestureHandler";
import PinchGestureHandler from "./screens/PinchGestureHandler";
import LongPressGestureHandler from "./screens/LongPressGestureHandler";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";

const Drawer = createDrawerNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: "Home" }}
        />
        <Drawer.Screen
          name="Configuração"
          component={ConfigScreen}
          options={{ title: "Config" }}
        />
        <Drawer.Screen
          name="Perfil"
          component={PerfilScreen}
          options={{ title: "Perfil" }}
        />
        <Drawer.Screen
          name="TapGestureHandler"
          component={TapGestureHandler}
          options={{ title: "TapGestureHandler" }}
        />
        <Drawer.Screen
          name="RotationGestureHandler"
          component={RotationGestureHandler}
          options={{ title: "RotationGestureHandler" }}
        />
        <Drawer.Screen
          name="PinchGestureHandler"
          component={PinchGestureHandler}
          options={{ title: "PinchGestureHandler" }}
        />
        <Drawer.Screen
          name="LongPressGestureHandler"
          component={LongPressGestureHandler}
          options={{ title: "LongPressGestureHandler" }}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
