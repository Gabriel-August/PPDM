import React, { useRef } from "react";
import {
  Animated,
  PanResponder,
  View,
  Text,
  StyleSheet,
  Dimensions,
  Platform,
} from "react-native";

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");
const ITEM_SIZE = 80; // tamanho do item arrastável
const TOP_SAFE = Platform.OS === "android" ? 0 : 30; // ajuste simples para iOS statusbar

export default function ArrastarDrag() {
  const pan = useRef(new Animated.ValueXY()).current;

  // utilitário para limitar valores dentro de um intervalo
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderGrant: () => {
        // prepara para arrastar preservando offset atual
        pan.setOffset({ x: pan.x._value || 0, y: pan.y._value || 0 });
        pan.setValue({ x: 0, y: 0 });
      },
      onPanResponderMove: Animated.event([null, { dx: pan.x, dy: pan.y }], {
        useNativeDriver: false,
      }),
      onPanResponderRelease: (_, gesture) => {
        // aplica offset e calcula posição final com limites da tela
        pan.flattenOffset();

        const minX = 0;
        const maxX = SCREEN_WIDTH - ITEM_SIZE;
        const minY = 0;
        const maxY = SCREEN_HEIGHT - ITEM_SIZE - TOP_SAFE;

        // valor atual após flattenOffset
        const finalX = clamp(pan.x._value, minX, maxX);
        const finalY = clamp(pan.y._value, minY, maxY);

        // anima para a posição válida (snap com mola)
        Animated.spring(pan, {
          toValue: { x: finalX, y: finalY },
          useNativeDriver: false,
          bounciness: 8,
        }).start();
      },
    })
  ).current;

  return (
    <View style={styles.container}>
      <Animated.View
        {...panResponder.panHandlers}
        style={[styles.draggable, { transform: pan.getTranslateTransform() }]}
      >
        <Text style={styles.text}>Arraste</Text>
      </Animated.View>
      <Text style={styles.hint}>Segure e arraste o círculo</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  draggable: {
    width: ITEM_SIZE,
    height: ITEM_SIZE,
    borderRadius: ITEM_SIZE / 2,
    backgroundColor: "#2979FF",
    alignItems: "center",
    justifyContent: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  text: {
    color: "#fff",
    fontWeight: "600",
  },
  hint: {
    position: "absolute",
    bottom: 40,
    color: "#666",
  },
});
