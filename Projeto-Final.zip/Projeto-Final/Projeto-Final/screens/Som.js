import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Button } from "react-native";
import { Audio } from "expo-av";
import React, { useEffect, useState } from "react";

export default function App() {
  const [sound, setSound] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLooping, setIsLooping] = useState(false);

  async function playSound() {
    // Cenário 1: O som ainda não foi carregado na memória
    if (!sound) {
      console.log('Carregando Som');
      const { sound: newSound } = await Audio.Sound.createAsync(
        // ATENÇÃO: Se este arquivo estiver na pasta 'screens', mude ./ para ../
        // @ts-ignore
        require("../assets/that-sounds-great_dream-on-aerosmith.mp3"), 
        { isLooping }
      );
      
      // @ts-ignore
      setSound(newSound);

      // CORREÇÃO IMPORTANTE: Monitora quando a música acaba sozinha
      newSound.setOnPlaybackStatusUpdate((status) => {
        // @ts-ignore
        if (status.didJustFinish && !status.isLooping) {
          setIsPlaying(false);
          newSound.setPositionAsync(0); // Volta para o começo para a próxima vez
        }
      });

      await newSound.playAsync();
      setIsPlaying(true);
    } 
    // Cenário 2: O som já existe, apenas damos play
    else {
      // @ts-ignore
      await sound.playAsync();
      setIsPlaying(true);
    }
  }

  async function pauseSound() {
    if (sound) {
      // @ts-ignore
      await sound.pauseAsync();
      setIsPlaying(false);
    }
  }

  async function toggleLoop() {
    if (sound) {
      // @ts-ignore
      await sound.setIsLoopingAsync(!isLooping);
    }
    setIsLooping((prev) => !prev);
  }

  async function restartSound() {
    if (sound) {
      // @ts-ignore
      await sound.stopAsync();
      // @ts-ignore
      await sound.setPositionAsync(0);
      // @ts-ignore
      await sound.playAsync();
      setIsPlaying(true);
    }
  }

  // Limpa a memória quando sai da tela
  useEffect(() => {
    return () => {
      if (sound) {
        // @ts-ignore
        sound.unloadAsync();
      }
    };
  }, [sound]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Reprodutor de Áudio</Text>
      
      <View style={styles.buttonContainer}>
        <Button
          title={isPlaying ? "Pausar" : "Tocar"}
          onPress={isPlaying ? pauseSound : playSound}
        />
      </View>

      <View style={styles.buttonContainer}>
        <Button
          title={isLooping ? "Repetir: Ligado" : "Repetir: Desligado"}
          onPress={toggleLoop}
          color={isLooping ? "#4caf50" : "#757575"}
        />
      </View>

      <View style={styles.buttonContainer}>
        <Button 
          title="Reiniciar Música" 
          onPress={restartSound} 
          color="#2196f3" 
        />
      </View>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    padding: 20, // Dá um respiro nas bordas
  },
  title: {
    fontSize: 24,
    marginBottom: 40,
    fontWeight: 'bold',
  },
  buttonContainer: {
    width: '100%', // Ocupa a largura disponível
    maxWidth: 300, // Mas não fica gigante em tablets
    marginBottom: 15, // Espaço entre os botões
  }
});