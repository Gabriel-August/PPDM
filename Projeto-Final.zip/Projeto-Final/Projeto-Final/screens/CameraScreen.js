import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Alert,
  SafeAreaView
} from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as MediaLibrary from "expo-media-library";
import { MaterialIcons, FontAwesome5 } from "@expo/vector-icons"; // Ícones

export default function CameraScreen() {
  const [photo, setPhoto] = useState(null);
  const [facing, setFacing] = useState("back");
  const [permission, requestPermission] = useCameraPermissions();
  const [mediaPermission, requestMediaPermission] = MediaLibrary.usePermissions();
  const cameraRef = useRef(null);

  // Pede permissão da galeria ao abrir
  useEffect(() => {
    if (!mediaPermission) {
      requestMediaPermission();
    }
  }, [mediaPermission]);

  // Tela de Carregando Permissão
  if (!permission) {
    return <View style={styles.container} />;
  }

  // Tela de Permissão Negada
  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <MaterialIcons name="no-photography" size={60} color="#666" />
        <Text style={styles.message}>Precisamos da sua permissão para usar a câmera</Text>
        <TouchableOpacity style={styles.btnPermission} onPress={requestPermission}>
          <Text style={styles.btnText}>Conceder Permissão</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Função de Tirar Foto
  const takePicture = async () => {
    if (cameraRef.current) {
      try {
        const photoData = await cameraRef.current.takePictureAsync({
          quality: 1, // Qualidade máxima
        });
        setPhoto(photoData.uri);
      } catch (error) {
        Alert.alert("Erro", "Não foi possível tirar a foto.");
      }
    }
  };

  // Função de Salvar Foto
  const savePhoto = async () => {
    if (mediaPermission?.granted) {
      try {
        await MediaLibrary.saveToLibraryAsync(photo);
        Alert.alert("Sucesso!", "Foto salva na galeria.");
        setPhoto(null); // Volta para a câmera
      } catch (e) {
        Alert.alert("Erro", "Falha ao salvar na galeria.");
      }
    } else {
      Alert.alert("Permissão necessária", "Não podemos salvar sem acesso à galeria.");
      requestMediaPermission();
    }
  };

  // Função de Virar Câmera
  function toggleCameraFacing() {
    setFacing((current) => (current === "back" ? "front" : "back"));
  }

  // --- MODO PRÉ-VISUALIZAÇÃO (FOTO TIRADA) ---
  if (photo) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.previewContainer}>
          <Image source={{ uri: photo }} style={styles.previewImage} resizeMode="contain" />
          
          <View style={styles.actionButtons}>
            {/* Botão Descartar */}
            <TouchableOpacity 
              style={[styles.btnAction, styles.btnDiscard]} 
              onPress={() => setPhoto(null)}
            >
              <MaterialIcons name="delete" size={24} color="#fff" />
              <Text style={styles.btnActionText}>Descartar</Text>
            </TouchableOpacity>

            {/* Botão Salvar */}
            <TouchableOpacity 
              style={[styles.btnAction, styles.btnSave]} 
              onPress={savePhoto}
            >
              <MaterialIcons name="save-alt" size={24} color="#fff" />
              <Text style={styles.btnActionText}>Salvar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // --- MODO CÂMERA (AO VIVO) ---
  return (
    <View style={styles.container}>
      <CameraView style={styles.camera} facing={facing} ref={cameraRef}>
        
        {/* Controles da Câmera (Fundo transparente) */}
        <View style={styles.cameraControls}>
          
          {/* Espaço vazio para centralizar o botão do meio */}
          <View style={{flex: 1}}></View>

          {/* Botão de Disparo (Grande no meio) */}
          <TouchableOpacity style={styles.captureButtonOuter} onPress={takePicture}>
            <View style={styles.captureButtonInner} />
          </TouchableOpacity>

          {/* Botão de Virar (Na direita) */}
          <View style={{flex: 1, alignItems: 'center'}}>
            <TouchableOpacity style={styles.flipButton} onPress={toggleCameraFacing}>
              <MaterialIcons name="flip-camera-ios" size={28} color="#fff" />
            </TouchableOpacity>
          </View>

        </View>
      </CameraView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  message: {
    textAlign: 'center',
    paddingBottom: 20,
    color: '#fff',
    fontSize: 16,
    marginTop: 20,
  },
  camera: {
    flex: 1,
    width: '100%',
  },
  // Controles da Câmera (Barra inferior)
  cameraControls: {
    position: 'absolute',
    bottom: 40,
    flexDirection: 'row',
    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 30,
  },
  // Botão de Disparo (Design estilo iPhone)
  captureButtonOuter: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 4,
    borderColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
  },
  captureButtonInner: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#fff',
  },
  flipButton: {
    backgroundColor: 'rgba(0,0,0,0.5)',
    padding: 12,
    borderRadius: 50,
  },
  // Botão de Permissão
  btnPermission: {
    backgroundColor: '#447cec',
    padding: 15,
    borderRadius: 10,
  },
  btnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  // Pré-visualização da Foto
  previewContainer: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  previewImage: {
    width: '100%',
    height: '80%',
    borderRadius: 10,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    padding: 20,
    position: 'absolute',
    bottom: 30,
  },
  btnAction: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 30,
    gap: 10,
  },
  btnDiscard: {
    backgroundColor: '#ff4757',
  },
  btnSave: {
    backgroundColor: '#2ed573',
  },
  btnActionText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});