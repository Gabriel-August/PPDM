import React, { useState } from "react";
import { View, Text, StyleSheet, Switch, StatusBar } from "react-native";


export default function ConfigScreen() {
  // 1. Estado para controlar se o modo escuro está ativado (false = claro, true = escuro)
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Função que inverte o valor (se tá claro vira escuro, e vice-versa)
  const toggleSwitch = () => setIsDarkMode(previousState => !previousState);

  return (
    // 2. Mudança dinâmica de estilo usando array []
    <View style={[styles.container, { backgroundColor: isDarkMode ? '#121212' : '#fff' }]}>
      
      <Text style={[styles.title, { color: isDarkMode ? '#fff' : '#000' }]}>
        {isDarkMode ? "Modo Escuro Ativado" : "Modo Claro Ativado"}
      </Text>

      <Text style={[styles.text, { color: isDarkMode ? '#ccc' : '#447cecff' }]}>
        Abra o menu Lateral
      </Text>

      {/* 3. O Botão de Interruptor */}
      <View style={styles.switchContainer}>
        <Text style={{ color: isDarkMode ? '#fff' : '#000', marginRight: 10 }}>
          Alterar Tema:
        </Text>
        <Switch
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={isDarkMode ? "#f5dd4b" : "#f4f3f4"}
          onValueChange={toggleSwitch}
          value={isDarkMode}
        />
      </View>

      {/* Muda a cor da barra de status do celular também */}
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 24,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  text: {
    fontSize: 18,
    marginBottom: 20,
  },
  switchContainer: {
    flexDirection: 'row', // Coloca o texto e o switch lado a lado
    alignItems: 'center',
    marginTop: 20,
  }
});