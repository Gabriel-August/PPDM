import "react-native-gesture-handler";
import React, { useState } from "react";
// 1. Não esqueça de importar o Image
import { View, Text, StyleSheet, Animated, Image } from "react-native";
import { PinchGestureHandler, GestureHandlerRootView } from "react-native-gesture-handler";

export default function App() {
  const [scale] = useState(new Animated.Value(1));

  const onPinchEvent = Animated.event([{ nativeEvent: { scale: scale } }], {
    useNativeDriver: true,
  });

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <Text style={styles.title}>Gesto de Pinça</Text>
        <Text style={styles.subtitle}>
          Use dois dedos para aumentar seu ícone.
        </Text>

        <PinchGestureHandler onGestureEvent={onPinchEvent}>
          <Animated.View
            style={[
              styles.card,
              {
                transform: [{ scale }],
              },
            ]}
          >
            {/* 2. AQUI A MÁGICA: Trocamos o Feather pela Image */}
            <Image 
              // Se for imagem local (do seu PC):
              source={require('../assets/blocoDeGelo.jpg')} 
              
              // Se fosse link da internet, seria: source={{ uri: 'https://...' }}
              
              style={styles.meuIcone} // Estilo novo que criamos abaixo
            />
            
          </Animated.View>
        </PinchGestureHandler>
      </View>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f4f4f8",
  },
  title: { fontSize: 24, fontWeight: "500", color: "#333", marginBottom: 10 },
  subtitle: { fontSize: 16, color: "#555", marginBottom: 40, textAlign: "center" },
  
  card: {
    width: 200, 
    height: 200,
    backgroundColor: "#fff",
    borderRadius: 16,
    justifyContent: "center", // Centraliza a imagem verticalmente
    alignItems: "center",     // Centraliza a imagem horizontalmente
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },

  // 3. Estilo para a imagem parecer um ícone
  meuIcone: {
    width: 100,  // Tamanho do ícone (largura)
    height: 80, // Tamanho do ícone (altura)
    resizeMode: 'contain' // Garante que a imagem inteira apareça sem cortar
  }
});