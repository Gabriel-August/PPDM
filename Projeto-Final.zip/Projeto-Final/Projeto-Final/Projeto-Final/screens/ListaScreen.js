import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  Alert, 
  FlatList, 
  Keyboard 
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';

export default function ListaScreen() {
    const [text, setText] = useState('');
    const [items, setItems] = useState([]);

    // --- Carregar dados ao iniciar ---
    useEffect(() => {
        const loadData = async () => {
            try {
                const value = await AsyncStorage.getItem('@my_items');
                if (value !== null) {
                    setItems(JSON.parse(value));
                }
            } catch (e) {
                Alert.alert('Erro', 'Não foi possível carregar sua lista.');
            }
        };
        loadData();
    }, []);

    // --- Salvar dados no celular ---
    const saveData = async (newItems) => {
        try {
            await AsyncStorage.setItem('@my_items', JSON.stringify(newItems));
        } catch (e) {
            Alert.alert('Erro', 'Falha ao salvar os dados.');
        }
    };

    // --- Adicionar Item ---
    const addItem = () => {
        if (text.trim() === '') {
            Alert.alert("Atenção", "Digite algo para adicionar!");
            return;
        }

        const newItems = [...items, text.trim()];
        setItems(newItems);
        saveData(newItems);
        setText('');
        Keyboard.dismiss(); // Fecha o teclado
    };

    // --- Excluir Item Único ---
    const deleteItem = (index) => {
        Alert.alert(
            "Excluir",
            "Deseja remover este item?",
            [
                { text: "Cancelar", style: "cancel" },
                { 
                    text: "Sim", 
                    onPress: () => {
                        const newItems = items.filter((_, i) => i !== index);
                        setItems(newItems);
                        saveData(newItems);
                    }
                }
            ]
        );
    };

    // --- Limpar Tudo ---
    const clearAll = () => {
        if (items.length === 0) return;

        Alert.alert(
            "Limpar Lista",
            "Tem certeza que deseja apagar TUDO?",
            [
                { text: "Cancelar", style: "cancel" },
                { 
                    text: "Apagar Tudo", 
                    style: "destructive",
                    onPress: async () => {
                        try {
                            await AsyncStorage.removeItem('@my_items');
                            setItems([]);
                        } catch (e) {
                            Alert.alert('Erro', 'Não foi possível limpar.');
                        }
                    }
                }
            ]
        );
    };

    return (
        <View style={styles.container}>
            
            {/* Cabeçalho */}
            <View style={styles.header}>
                <MaterialIcons name="playlist-add-check" size={40} color="#447cec" />
                <Text style={styles.title}>Minhas Tarefas</Text>
                <Text style={styles.subtitle}>Não esqueça de nada!</Text>
            </View>

            {/* Área de Input */}
            <View style={styles.inputContainer}>
                <TextInput
                    style={styles.input}
                    placeholder="O que precisa ser feito?"
                    placeholderTextColor="#999"
                    value={text}
                    onChangeText={setText}
                />
                <TouchableOpacity style={styles.addButton} onPress={addItem}>
                    <Ionicons name="add" size={30} color="#fff" />
                </TouchableOpacity>
            </View>

            {/* Lista */}
            <FlatList
                data={items}
                keyExtractor={(item, index) => index.toString()}
                contentContainerStyle={{ paddingBottom: 100 }}
                showsVerticalScrollIndicator={false}
                renderItem={({ item, index }) => (
                    <View style={styles.card}>
                        <View style={styles.itemTextContainer}>
                            <MaterialIcons name="radio-button-unchecked" size={20} color="#447cec" />
                            <Text style={styles.itemText}>{item}</Text>
                        </View>
                        
                        <TouchableOpacity onPress={() => deleteItem(index)}>
                            <MaterialIcons name="delete-outline" size={24} color="#ff4757" />
                        </TouchableOpacity>
                    </View>
                )}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <Text style={styles.emptyText}>Nenhuma tarefa por enquanto...</Text>
                    </View>
                }
            />

            {/* Botão Flutuante de Limpar Tudo (Só aparece se tiver itens) */}
            {items.length > 0 && (
                <TouchableOpacity style={styles.clearButton} onPress={clearAll}>
                    <MaterialIcons name="delete-sweep" size={24} color="#fff" />
                    <Text style={styles.clearButtonText}>Limpar Lista</Text>
                </TouchableOpacity>
            )}

        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F2F4F8', // Cinza claro moderno
        padding: 20,
        paddingTop: 50,
    },
    header: {
        alignItems: 'center',
        marginBottom: 30,
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#333',
        marginTop: 5,
    },
    subtitle: {
        fontSize: 16,
        color: '#666',
    },
    // Input
    inputContainer: {
        flexDirection: 'row',
        marginBottom: 20,
        gap: 10,
    },
    input: {
        flex: 1,
        backgroundColor: '#fff',
        padding: 15,
        borderRadius: 12,
        fontSize: 16,
        elevation: 2, // Sombra Android
        shadowColor: '#000', // Sombra iOS
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    addButton: {
        backgroundColor: '#447cec',
        width: 55,
        height: 55,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 2,
    },
    // Lista / Card
    card: {
        backgroundColor: '#fff',
        padding: 15,
        borderRadius: 12,
        marginBottom: 10,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        elevation: 1,
        shadowColor: '#000',
        shadowOpacity: 0.05,
        shadowRadius: 2,
    },
    itemTextContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        flex: 1, // Para o texto não empurrar o botão de deletar
    },
    itemText: {
        fontSize: 16,
        color: '#333',
    },
    // Vazio
    emptyContainer: {
        alignItems: 'center',
        marginTop: 50,
    },
    emptyText: {
        color: '#999',
        fontStyle: 'italic',
    },
    // Botão Limpar Tudo
    clearButton: {
        flexDirection: 'row',
        backgroundColor: '#ff4757',
        padding: 15,
        borderRadius: 30,
        justifyContent: 'center',
        alignItems: 'center',
        gap: 10,
        marginTop: 10,
        elevation: 5,
    },
    clearButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    }
});