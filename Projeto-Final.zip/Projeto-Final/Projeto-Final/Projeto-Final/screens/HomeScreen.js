import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      {/* CORREÇÃO AQUI: Use require para arquivos da pasta assets */}
      <Image 
        source={require('../assets/telaInicial.jpg')} 
        style={styles.Inicio} 
      />
      <Text style={styles.title}>Seja bem vindo ao Projeto</Text>
      <Text style={styles.text}>Abra o menu Lateral</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 24,
    marginBottom: 10,
    textAlign: 'center', // centralizar se o texto quebrar linha
  },
  text: {
    color: "#447cecff",
    fontSize: 24,
  },
  Inicio: {
    width: 300, // Aumenta a imagem
    height: 200,
    marginBottom: 20, 
    borderRadius: 10, // Dica: Arredonda
  },
});