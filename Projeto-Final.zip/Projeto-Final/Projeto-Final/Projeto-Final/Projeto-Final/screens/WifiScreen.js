import React, { useEffect, useState, useRef } from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  Alert, 
  StyleSheet, 
  ScrollView, 
  Platform 
} from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import * as Location from 'expo-location';
import { MaterialIcons, FontAwesome5, Ionicons } from '@expo/vector-icons';

export default function WifiScreen() {
  const [netInfo, setNetInfo] = useState(null);
  const [history, setHistory] = useState([]);
  const previousConnection = useRef(null);

  // --- Lógica de Permissão e Atualização ---

  useEffect(() => {
    // 1. Pede permissão de localização (Necessário no Android para ver o nome do Wi-Fi)
    (async () => {
      if (Platform.OS === 'android') {
        await Location.requestForegroundPermissionsAsync();
      }
    })();

    // 2. Escuta mudanças na rede em tempo real
    const unsubscribe = NetInfo.addEventListener(state => updateState(state));

    // 3. Busca estado inicial
    refreshStatus();

    return () => unsubscribe();
  }, []);

  const refreshStatus = async () => {
    const state = await NetInfo.fetch();
    updateState(state);
  };

  const updateState = (state) => {
    setNetInfo(state);

    // Evita logar a mesma coisa várias vezes se o status não mudou
    if (previousConnection.current === state.isConnected) return;

    // Cria mensagem do histórico
    const connectionType = state.type === "wifi" 
      ? `Wi-Fi: ${state.details?.ssid || "Rede Oculta/Desconhecida"}` 
      : `Dados: ${state.type.toUpperCase()}`;

    const timestamp = new Date().toLocaleTimeString();
    const statusText = state.isConnected ? "CONECTOU" : "DESCONECTOU";
    
    const newEntry = {
      id: Date.now().toString(),
      time: timestamp,
      status: statusText,
      detail: state.isConnected ? connectionType : "Sem Internet",
      connected: state.isConnected
    };

    setHistory(prev => [newEntry, ...prev]);

    // Alerta se cair
    if (previousConnection.current === true && state.isConnected === false) {
      Alert.alert("Atenção", "Sua conexão com a internet caiu!");
    }

    previousConnection.current = state.isConnected;
  };

  // --- Função para limpar histórico ---
  const clearHistory = () => {
    setHistory([]);
  };

  // --- Renderização ---

  // Variáveis visuais baseadas no estado
  const isConnected = netInfo?.isConnected;
  const isWifi = netInfo?.type === 'wifi';
  const ssidName = isWifi ? (netInfo.details?.ssid || "Wi-Fi Desconhecido") : "---";
  const ipAddress = netInfo?.details?.ipAddress || "---";

  return (
    <ScrollView contentContainerStyle={styles.container}>
      
      {/* Cabeçalho */}
      <View style={styles.header}>
        <MaterialIcons name="wifi-tethering" size={40} color="#447cec" />
        <Text style={styles.title}>Monitor de Rede</Text>
        <Text style={styles.subtitle}>Status da conexão em tempo real</Text>
      </View>

      {/* Card Principal (Status Visual) */}
      <View style={[styles.statusCard, isConnected ? styles.connectedCard : styles.disconnectedCard]}>
        <View style={styles.iconContainer}>
            <MaterialIcons 
                name={isConnected ? "wifi" : "signal-wifi-off"} 
                size={50} 
                color="#fff" 
            />
        </View>
        <Text style={styles.statusTitle}>
            {isConnected ? "CONECTADO" : "DESCONECTADO"}
        </Text>
        <Text style={styles.statusSubtitle}>
            {isConnected ? (isWifi ? "Rede Wi-Fi Ativa" : "Dados Móveis Ativos") : "Verifique sua conexão"}
        </Text>
      </View>

      {/* Grid de Detalhes */}
      <View style={styles.detailsContainer}>
        <View style={styles.detailBox}>
            <Text style={styles.label}>Tipo de Rede</Text>
            <Text style={styles.value}>{netInfo?.type?.toUpperCase() || "--"}</Text>
        </View>

        <View style={styles.detailBox}>
            <Text style={styles.label}>SSID (Nome)</Text>
            <Text style={styles.value} numberOfLines={1}>{ssidName}</Text>
        </View>

        <View style={styles.detailBox}>
            <Text style={styles.label}>Endereço IP</Text>
            <Text style={styles.value}>{ipAddress}</Text>
        </View>

        <View style={styles.detailBox}>
            <Text style={styles.label}>Internet</Text>
            <Text style={[styles.value, {color: netInfo?.isInternetReachable ? 'green' : 'orange'}]}>
                {netInfo?.isInternetReachable ? "Acessível" : "Limitada"}
            </Text>
        </View>
      </View>

      {/* Botão Atualizar */}
      <TouchableOpacity style={styles.refreshButton} onPress={refreshStatus}>
        <Ionicons name="refresh-circle" size={24} color="#fff" />
        <Text style={styles.buttonText}>Atualizar Status Agora</Text>
      </TouchableOpacity>

      {/* Histórico */}
      <View style={styles.historySection}>
        <View style={styles.historyHeader}>
            <Text style={styles.historyTitle}>Histórico de Eventos</Text>
            <TouchableOpacity onPress={clearHistory}>
                <Text style={styles.clearText}>Limpar</Text>
            </TouchableOpacity>
        </View>

        <View style={styles.logContainer}>
            {history.length === 0 ? (
                <Text style={styles.emptyText}>Nenhum evento registrado ainda.</Text>
            ) : (
                history.map((item) => (
                    <View key={item.id} style={styles.logItem}>
                        <View style={styles.logTimeBox}>
                            <Text style={styles.logTime}>{item.time}</Text>
                        </View>
                        <View style={styles.logContent}>
                            <Text style={[styles.logStatus, {color: item.connected ? 'green' : 'red'}]}>
                                {item.status}
                            </Text>
                            <Text style={styles.logDetail}>{item.detail}</Text>
                        </View>
                    </View>
                ))
            )}
        </View>
      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#F2F4F8',
    padding: 20,
    paddingTop: 50,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
  },
  // Card Principal
  statusCard: {
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20,
    elevation: 4,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  connectedCard: {
    backgroundColor: '#4caf50',
  },
  disconnectedCard: {
    backgroundColor: '#ff4757',
  },
  iconContainer: {
    marginBottom: 10,
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: 15,
    borderRadius: 50,
  },
  statusTitle: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  statusSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
  },
  // Grid de Detalhes
  detailsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  detailBox: {
    width: '48%',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    elevation: 2,
  },
  label: {
    fontSize: 12,
    color: '#888',
    marginBottom: 4,
  },
  value: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  // Botão
  refreshButton: {
    backgroundColor: '#447cec',
    flexDirection: 'row',
    padding: 15,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
    gap: 10,
    elevation: 3,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  // Histórico
  historySection: {
    flex: 1,
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  historyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  clearText: {
    color: '#ff4757',
    fontWeight: 'bold',
  },
  logContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 10,
    elevation: 2,
    minHeight: 150,
  },
  emptyText: {
    color: '#999',
    textAlign: 'center',
    marginTop: 20,
    fontStyle: 'italic',
  },
  logItem: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    paddingVertical: 10,
  },
  logTimeBox: {
    width: 80,
    justifyContent: 'center',
  },
  logTime: {
    fontSize: 12,
    color: '#666',
    fontWeight: 'bold',
  },
  logContent: {
    flex: 1,
  },
  logStatus: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  logDetail: {
    fontSize: 12,
    color: '#555',
  }
});