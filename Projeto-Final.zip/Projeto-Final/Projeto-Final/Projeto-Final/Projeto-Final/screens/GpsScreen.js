import React, { useState, useEffect } from "react";
import { StyleSheet, Text, View, TouchableOpacity, ScrollView, Platform, Alert } from "react-native";
import * as Location from "expo-location";
import { MaterialIcons, FontAwesome5 } from "@expo/vector-icons"; // Ícones para deixar bonito

export default function GpsScreen() {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [isTracking, setIsTracking] = useState(false);

  // --- Funções de Lógica (Iguais às suas, mas organizadas) ---

  const getLocation = async () => {
    try {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setErrorMsg("Permissão negada! O GPS precisa de permissão.");
        Alert.alert("Erro", "Permissão de localização negada.");
        return;
      }

      let currentLocation = await Location.getCurrentPositionAsync({});
      setLocation(currentLocation);
      setErrorMsg(null);
    } catch (error) {
      setErrorMsg("Erro ao buscar: " + error.message);
    }
  };

  const startTracking = async () => {
    try {
      if (isTracking) return;

      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") return;

      const sub = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 2000, // 2 segundos
          distanceInterval: 1, // 1 metro
        },
        (loc) => {
          setLocation(loc);
        }
      );

      setSubscription(sub);
      setIsTracking(true);
      setErrorMsg(null);
    } catch (error) {
      setErrorMsg("Erro no rastreamento: " + error.message);
    }
  };

  const stopTracking = () => {
    if (subscription) {
      subscription.remove();
      setSubscription(null);
      setIsTracking(false);
    }
  };

  // Limpeza automática ao sair da tela
  useEffect(() => {
    getLocation(); // Pega a primeira vez ao abrir
    return () => {
      if (subscription) subscription.remove();
    };
  }, []);

  // --- Renderização Visual ---

  return (
    <ScrollView contentContainerStyle={styles.container}>
      
      {/* Cabeçalho */}
      <View style={styles.header}>
        <MaterialIcons name="satellite" size={40} color="#447cec" />
        <Text style={styles.title}>Monitor GPS</Text>
        <Text style={styles.subtitle}>Dados de satélite em tempo real</Text>
      </View>

      {/* Cartão Principal de Status */}
      <View style={[styles.card, isTracking ? styles.cardActive : styles.cardInactive]}>
        <Text style={styles.statusTitle}>STATUS DO RASTREADOR</Text>
        <View style={styles.statusRow}>
          <FontAwesome5 
            name={isTracking ? "satellite-dish" : "pause-circle"} 
            size={24} 
            color={isTracking ? "#fff" : "#666"} 
          />
          <Text style={isTracking ? styles.statusTextActive : styles.statusTextInactive}>
            {isTracking ? "Rastreando..." : "Parado"}
          </Text>
        </View>
      </View>

      {/* Grid de Dados */}
      {location ? (
        <View style={styles.dataGrid}>
          {/* Latitude */}
          <View style={styles.dataItem}>
            <Text style={styles.label}>Latitude</Text>
            <Text style={styles.value}>{location.coords.latitude.toFixed(5)}</Text>
          </View>

          {/* Longitude */}
          <View style={styles.dataItem}>
            <Text style={styles.label}>Longitude</Text>
            <Text style={styles.value}>{location.coords.longitude.toFixed(5)}</Text>
          </View>

          {/* Altitude */}
          <View style={styles.dataItem}>
            <Text style={styles.label}>Altitude</Text>
            <Text style={styles.value}>
              {location.coords.altitude ? `${location.coords.altitude.toFixed(1)} m` : "--"}
            </Text>
          </View>

          {/* Velocidade (Multipliquei por 3.6 para converter m/s para km/h) */}
          <View style={styles.dataItem}>
            <Text style={styles.label}>Velocidade</Text>
            <Text style={styles.value}>
              {location.coords.speed ? `${(location.coords.speed * 3.6).toFixed(1)} km/h` : "0 km/h"}
            </Text>
          </View>
        </View>
      ) : (
        <View style={styles.loadingBox}>
          <Text style={styles.loadingText}>
            {errorMsg ? errorMsg : "Aguardando sinal do GPS..."}
          </Text>
        </View>
      )}

      {/* Botões de Controle */}
      <View style={styles.controls}>
        <TouchableOpacity 
          style={[styles.button, styles.btnUpdate]} 
          onPress={getLocation}
        >
          <MaterialIcons name="my-location" size={24} color="#fff" />
          <Text style={styles.btnText}>Atualizar Agora</Text>
        </TouchableOpacity>

        <View style={styles.rowButtons}>
          <TouchableOpacity 
            style={[styles.button, styles.btnStart, isTracking && styles.btnDisabled]} 
            onPress={startTracking}
            disabled={isTracking}
          >
            <Text style={styles.btnText}>Iniciar</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.button, styles.btnStop, !isTracking && styles.btnDisabled]} 
            onPress={stopTracking}
            disabled={!isTracking}
          >
            <Text style={styles.btnText}>Parar</Text>
          </TouchableOpacity>
        </View>
      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: "#F2F4F8",
    alignItems: "center",
    padding: 20,
    paddingTop: 50,
  },
  header: {
    alignItems: "center",
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
    marginTop: 10,
  },
  subtitle: {
    fontSize: 16,
    color: "#666",
  },
  // Cartão de Status
  card: {
    width: "100%",
    padding: 20,
    borderRadius: 15,
    marginBottom: 20,
    elevation: 4, // Sombra Android
    shadowColor: "#000", // Sombra iOS
    shadowOpacity: 0.1,
    shadowRadius: 5,
    alignItems: "center",
  },
  cardActive: {
    backgroundColor: "#4caf50", // Verde quando ativo
  },
  cardInactive: {
    backgroundColor: "#fff", // Branco quando parado
  },
  statusTitle: {
    fontSize: 12,
    fontWeight: "bold",
    opacity: 0.8,
    color: "#333",
    marginBottom: 5,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  statusTextActive: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "bold",
  },
  statusTextInactive: {
    color: "#666",
    fontSize: 20,
    fontWeight: "bold",
  },
  // Grid de Dados
  dataGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    width: "100%",
    marginBottom: 20,
  },
  dataItem: {
    width: "48%", // Dois itens por linha
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    elevation: 2,
    alignItems: "center",
  },
  label: {
    fontSize: 14,
    color: "#888",
    marginBottom: 5,
  },
  value: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
  },
  // Loading
  loadingBox: {
    height: 100,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    color: "#888",
    fontStyle: "italic",
  },
  // Botões
  controls: {
    width: "100%",
    gap: 10,
  },
  rowButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 10,
  },
  button: {
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
    elevation: 2,
  },
  btnUpdate: {
    backgroundColor: "#447cec", // Azul do seu projeto
    width: "100%",
    marginBottom: 10,
  },
  btnStart: {
    backgroundColor: "#2196f3",
    flex: 1,
  },
  btnStop: {
    backgroundColor: "#f44336",
    flex: 1,
  },
  btnDisabled: {
    backgroundColor: "#ccc",
    elevation: 0,
  },
  btnText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});