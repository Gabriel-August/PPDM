import "react-native-gesture-handler";
import React, { useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  Animated,
  TouchableOpacity,
} from "react-native";
import {
  RotationGestureHandler,
  GestureHandlerRootView,
  State,
} from "react-native-gesture-handler";
import { MaterialIcons } from "@expo/vector-icons";

export default function RotationScreen() {
  // Usamos useRef para garantir performance na animação
  const rotate = useRef(new Animated.Value(0)).current;

  const onRotateEvent = Animated.event(
    [{ nativeEvent: { rotation: rotate } }],
    { useNativeDriver: true }
  );

  // Função para quando soltar o dedo (opcional: dar um efeito visual)
  const onHandlerStateChange = (event) => {
    if (event.nativeEvent.oldState === State.ACTIVE) {
      // Aqui você poderia salvar o valor final se quisesse manter a rotação
      // Por enquanto, ele volta visualmente ao iniciar novo gesto pela natureza do handler básico
    }
  };

  // Função para Resetar
  const resetRotation = () => {
    Animated.spring(rotate, {
      toValue: 0,
      useNativeDriver: true,
      friction: 5,
    }).start();
  };

  return (
    // 1. OBRIGATÓRIO PARA ANDROID
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <View style={styles.header}>
          <MaterialIcons name="crop-rotate" size={40} color="#447cec" />
          <Text style={styles.title}>Rotação</Text>
          <Text style={styles.subtitle}>
            Faça o movimento de pinça giratória
          </Text>
        </View>

        {/* Área do Gesto */}
        <RotationGestureHandler
          onGestureEvent={onRotateEvent}
          onHandlerStateChange={onHandlerStateChange}
        >
          <Animated.View
            style={[
              styles.card,
              {
                transform: [
                  {
                    rotate: rotate.interpolate({
                      inputRange: [-Math.PI, Math.PI],
                      outputRange: ["-180deg", "180deg"], // Usando deg é mais fácil de entender
                    }),
                  },
                ],
              },
            ]}
          >
            <MaterialIcons name="navigation" size={50} color="#fff" />
            <Text style={styles.cardText}>GIRE-ME</Text>
          </Animated.View>
        </RotationGestureHandler>

        {/* Botão de Reset */}
        <TouchableOpacity style={styles.resetButton} onPress={resetRotation}>
          <MaterialIcons name="refresh" size={24} color="#fff" />
          <Text style={styles.resetText}>Resetar Posição</Text>
        </TouchableOpacity>
      </View>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F4F8", // Fundo cinza moderno
    justifyContent: "center",
    alignItems: "center",
  },
  header: {
    alignItems: "center",
    marginBottom: 50,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginTop: 10,
  },
  subtitle: {
    fontSize: 16,
    color: "#888",
  },
  // O Quadrado agora é um Card bonito
  card: {
    width: 200,
    height: 200,
    backgroundColor: "#447cec", // Azul do seu tema
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    // Sombras
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
  },
  cardText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 20,
    marginTop: 10,
    letterSpacing: 2,
  },
  // Botão Reset
  resetButton: {
    flexDirection: "row",
    backgroundColor: "#ff4757",
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 30,
    marginTop: 60,
    alignItems: "center",
    gap: 10,
    elevation: 5,
  },
  resetText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});
