import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, Alert, ActivityIndicator, Platform } from "react-native";
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';

export default function MapaScreen() {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);

  useEffect(() => {
    (async () => {
      // 1. Pede permissão para usar o GPS
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permissão de localização foi negada!');
        return;
      }

      // 2. Pega a localização atual
      let loc = await Location.getCurrentPositionAsync({});
      setLocation(loc.coords);
    })();
  }, []);

  // --- Tratamento para WEB (Evita erros no navegador) ---
  if (Platform.OS === 'web') {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>
          O Mapa não é suportado diretamente na Web neste modo. 
          Por favor, teste no Celular (Expo Go) ou Emulador.
        </Text>
      </View>
    );
  }

  // --- Tela de Carregamento ---
  if (!location) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#447cec" />
        <Text style={styles.loadingText}>Buscando sua localização...</Text>
        {errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}
      </View>
    );
  }

  // --- O Mapa ---
  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: location.latitude,
          longitude: location.longitude,
          latitudeDelta: 0.005, // Zoom mais próximo
          longitudeDelta: 0.005,
        }}
        showsUserLocation={true} // Mostra a bolinha azul pulsando onde você está
      >
        <Marker
          coordinate={{
            latitude: location.latitude,
            longitude: location.longitude,
          }}
          title="Você está aqui"
          description="Sua localização atual"
          pinColor="blue" // Muda a cor do pino para azul
        />
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  map: {
    width: '100%',
    height: '100%',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F2F4F8',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  errorText: {
    color: 'red',
    fontSize: 16,
    textAlign: 'center',
    margin: 20,
  }
});