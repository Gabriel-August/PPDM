import { StatusBar } from "expo-status-bar";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { Audio } from "expo-av";
import React, { useEffect, useState } from "react";
import { MaterialIcons, Ionicons } from "@expo/vector-icons";

export default function Som() {
  const [sound, setSound] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLooping, setIsLooping] = useState(false);

  // Estado para evitar que o botão trave enquanto carrega
  const [isLoading, setIsLoading] = useState(false);

  async function playSound() {
    setIsLoading(true); // Bloqueia cliques visualmente
    try {
      if (!sound) {
        // Carrega o som se ainda não existe
        // ATENÇÃO: O arquivo deve estar na pasta assets com EXATAMENTE este nome
        const { sound: newSound } = await Audio.Sound.createAsync(
          require("../assets/Scorpion_-_Wind_of_change_(mp3.pm).mp3"),
          { isLooping }
        );

        setSound(newSound);

        // Monitora o fim da música
        newSound.setOnPlaybackStatusUpdate((status) => {
          if (status.didJustFinish && !status.isLooping) {
            setIsPlaying(false);
            newSound.setPositionAsync(0);
          }
        });

        await newSound.playAsync();
        setIsPlaying(true);
      } else {
        // Se já existe, apenas toca
        await sound.playAsync();
        setIsPlaying(true);
      }
    } catch (error) {
      console.log("Erro ao tocar:", error);
    } finally {
      setIsLoading(false); // Libera o botão
    }
  }

  async function pauseSound() {
    setIsLoading(true); // Bloqueia cliques visualmente
    try {
      if (sound) {
        await sound.pauseAsync();
        setIsPlaying(false);
      }
    } catch (error) {
      console.log("Erro ao pausar:", error);
    } finally {
      setIsLoading(false); // Libera o botão
    }
  }

  async function toggleLoop() {
    if (sound) {
      await sound.setIsLoopingAsync(!isLooping);
    }
    setIsLooping((prev) => !prev);
  }

  async function restartSound() {
    if (sound) {
      try {
        await sound.stopAsync();
        await sound.setPositionAsync(0);
        await sound.playAsync();
        setIsPlaying(true);
      } catch (error) {
        console.log("Erro ao reiniciar:", error);
      }
    }
  }

  // Limpa a memória ao sair da tela
  useEffect(() => {
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, [sound]);

  return (
    <View style={styles.container}>
      {/* --- CAPA DO ÁLBUM --- */}
      <View style={styles.albumContainer}>
        <View style={styles.albumCircle}>
          <MaterialIcons name="music-note" size={80} color="#fff" />
        </View>
      </View>

      {/* --- INFORMAÇÕES (Atualizadas) --- */}
      <View style={styles.infoContainer}>
        <Text style={styles.songTitle}>Wind of Change</Text>
        <Text style={styles.artistName}>Scorpions</Text>
      </View>

      {/* --- CONTROLES --- */}
      <View style={styles.controlsContainer}>
        {/* Loop */}
        <TouchableOpacity onPress={toggleLoop} style={styles.sideButton}>
          <MaterialIcons
            name="loop"
            size={24}
            color={isLooping ? "#4caf50" : "#ccc"}
          />
          <Text
            style={[styles.label, { color: isLooping ? "#4caf50" : "#ccc" }]}
          >
            {isLooping ? "1" : "All"}
          </Text>
        </TouchableOpacity>

        {/* Reiniciar */}
        <TouchableOpacity onPress={restartSound} style={styles.sideButton}>
          <MaterialIcons name="skip-previous" size={45} color="#333" />
        </TouchableOpacity>

        {/* PLAY / PAUSE (Com proteção de Loading) */}
        <TouchableOpacity
          disabled={isLoading} // Desabilita o toque se estiver carregando
          onPress={isPlaying ? pauseSound : playSound}
          style={[styles.playButton, { opacity: isLoading ? 0.8 : 1 }]}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Ionicons
              name={isPlaying ? "pause" : "play"}
              size={40}
              color="#fff"
              style={{ marginLeft: isPlaying ? 0 : 5 }}
            />
          )}
        </TouchableOpacity>

        {/* Próximo (Visual) */}
        <TouchableOpacity style={styles.sideButton}>
          <MaterialIcons name="skip-next" size={45} color="#333" />
        </TouchableOpacity>

        {/* Lista (Visual) */}
        <TouchableOpacity style={styles.sideButton}>
          <MaterialIcons name="queue-music" size={24} color="#ccc" />
        </TouchableOpacity>
      </View>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F4F8",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  albumContainer: {
    marginBottom: 40,
    elevation: 15,
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 10 },
  },
  albumCircle: {
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: "#447cec",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 6,
    borderColor: "#fff",
  },
  infoContainer: {
    alignItems: "center",
    marginBottom: 50,
  },
  songTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 8,
    textAlign: "center",
  },
  artistName: {
    fontSize: 18,
    color: "#888",
    fontWeight: "500",
  },
  controlsContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    paddingHorizontal: 10,
  },
  sideButton: {
    alignItems: "center",
    justifyContent: "center",
    padding: 10,
  },
  label: {
    fontSize: 10,
    fontWeight: "bold",
    marginTop: 4,
  },
  playButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "#447cec",
    justifyContent: "center",
    alignItems: "center",
    elevation: 8,
    shadowColor: "#447cec",
    shadowOpacity: 0.5,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
});
