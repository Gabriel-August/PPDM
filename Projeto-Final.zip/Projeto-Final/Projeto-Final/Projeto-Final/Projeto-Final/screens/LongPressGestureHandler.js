import "react-native-gesture-handler";
import React, { useState, useRef } from "react";
import { View, Text, StyleSheet, Animated } from "react-native";
import {
  LongPressGestureHandler,
  State,
  GestureHandlerRootView,
} from "react-native-gesture-handler";
import * as Haptics from "expo-haptics"; // Para vibrar o celular
import { MaterialIcons } from "@expo/vector-icons";

export default function LongPressScreen() {
  const [activated, setActivated] = useState(false);

  // Valor animado (vai de 0 a 1)
  const progress = useRef(new Animated.Value(0)).current;

  const onHandlerStateChange = ({ nativeEvent }) => {
    if (nativeEvent.state === State.BEGAN) {
      // 1. Quando começa a segurar: Animação de "pressionar" (diminui um pouco)
      Animated.spring(progress, {
        toValue: 0.2, // Vai até 20% da animação
        useNativeDriver: false, // false porque vamos animar cor
      }).start();
    }

    if (nativeEvent.state === State.ACTIVE) {
      // 2. Quando o tempo (1s) completa: SUCESSO!
      setActivated(true);

      // Vibração de Sucesso (Feedback Tátil)
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

      // Animação de "Explosão" (Aumenta e muda de cor total)
      Animated.spring(progress, {
        toValue: 1,
        friction: 3,
        useNativeDriver: false,
      }).start();
    }

    if (
      nativeEvent.state === State.END ||
      nativeEvent.state === State.FAILED ||
      nativeEvent.state === State.CANCELLED
    ) {
      // 3. Se soltar antes da hora: Reseta tudo
      if (nativeEvent.state !== State.ACTIVE) {
        setActivated(false);
        Animated.spring(progress, {
          toValue: 0,
          useNativeDriver: false,
        }).start();
      }
    }
  };

  // --- Interpolações (Transformar números em Cores e Tamanho) ---

  // Cor muda de Cinza/Azul Escuro para Verde Sucesso
  const backgroundColor = progress.interpolate({
    inputRange: [0, 1],
    outputRange: ["#447cec", "#4caf50"],
  });

  // Escala: Normal (1) -> Pressionado (0.9) -> Sucesso (1.1)
  const scale = progress.interpolate({
    inputRange: [0, 0.2, 1],
    outputRange: [1, 0.9, 1.1],
  });

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>
            {activated ? "DESBLOQUEADO!" : "Toque Longo"}
          </Text>
          <Text style={styles.subtitle}>
            {activated
              ? "Ação confirmada com sucesso."
              : "Segure o botão por 1 segundo para ativar"}
          </Text>
        </View>

        <LongPressGestureHandler
          onHandlerStateChange={onHandlerStateChange}
          minDurationMs={800} // 800ms é um tempo mais confortável que 1000ms
        >
          <Animated.View
            style={[
              styles.button,
              {
                backgroundColor: backgroundColor,
                transform: [{ scale: scale }],
              },
            ]}
          >
            <MaterialIcons
              name={activated ? "check-circle" : "fingerprint"}
              size={60}
              color="#fff"
            />
            <Text style={styles.buttonText}>
              {activated ? "SUCESSO" : "SEGURE"}
            </Text>
          </Animated.View>
        </LongPressGestureHandler>

        {/* Botão para resetar o teste (se já tiver ativado) */}
        {activated && (
          <Text
            style={styles.resetText}
            onPress={() => {
              setActivated(false);
              progress.setValue(0);
            }}
          >
            Toque aqui para resetar
          </Text>
        )}
      </View>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F2F4F8",
    padding: 20,
  },
  header: {
    alignItems: "center",
    marginBottom: 50,
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: "#666",
    textAlign: "center",
  },
  // O Botão Bonito
  button: {
    width: 180,
    height: 180,
    borderRadius: 90, // Redondo
    justifyContent: "center",
    alignItems: "center",
    // Sombras
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 10,
    letterSpacing: 1,
  },
  resetText: {
    marginTop: 50,
    color: "#888",
    textDecorationLine: "underline",
    fontSize: 16,
  },
});
