import React, { useState, useEffect } from "react";
import { Text, View, StyleSheet, Platform, Dimensions } from "react-native";
import { Accelerometer } from "expo-sensors";

// Pegamos o tamanho da tela para centralizar as coisas
const { width } = Dimensions.get("window");
const CIRCLE_SIZE = 50; // Tamanho da bolinha

export default function Acelerometro() {
  const [data, setData] = useState({ x: 0, y: 0, z: 0 });
  const [erro, setErro] = useState(null);

  useEffect(() => {
    let subscription;

    if (Platform.OS === "web") {
      // --- LÓGICA WEB ---
      const handleMotion = (event) => {
        if (event.accelerationIncludingGravity) {
          const { x, y, z } = event.accelerationIncludingGravity;
          // Na web, os eixos as vezes são invertidos ou multiplicados dependendo do browser
          // Dividimos por 9.8 para normalizar parecido com o mobile (g=1)
          setData({
            x: (x || 0) / 9.8,
            y: (y || 0) / 9.8,
            z: (z || 0) / 9.8,
          });
        }
      };

      if (typeof window !== "undefined" && "DeviceMotionEvent" in window) {
        window.addEventListener("devicemotion", handleMotion);
      } else {
        setErro("Acelerômetro não suportado neste navegador.");
      }

      return () => {
        window.removeEventListener("devicemotion", handleMotion);
      };
    } else {
      // --- LÓGICA MOBILE (EXPO) ---
      const iniciar = async () => {
        try {
          const disponivel = await Accelerometer.isAvailableAsync();
          if (!disponivel) {
            setErro("Sensor não disponível.");
            return;
          }

          // Slow deixa a bolinha mais suave, Fast deixa mais ágil
          Accelerometer.setUpdateInterval(50);
          subscription = Accelerometer.addListener(setData);
        } catch (e) {
          setErro("Erro ao acessar sensor.");
        }
      };

      iniciar();

      return () => {
        subscription && subscription.remove();
      };
    }
  }, []);

  const { x, y } = data;

  // Lógica para verificar se está nivelado (perto de 0)
  const isLevel = Math.abs(x) < 0.05 && Math.abs(y) < 0.05;

  // Multiplicador para mover a bolinha (quanto maior, mais sensível)
  const multiplier = 150;

  // Posição da bolinha baseada na inclinação
  // Limitamos para a bolinha não sair da tela (clamp)
  const topPosition = Math.max(-140, Math.min(140, -y * multiplier));
  const leftPosition = Math.max(-140, Math.min(140, x * multiplier));

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Nível de Bolha</Text>
      <Text style={styles.subtitle}>Deixe o celular reto na mesa</Text>

      {/* Círculo Maior (O Alvo) */}
      <View
        style={[
          styles.outerCircle,
          isLevel ? styles.borderGreen : styles.borderRed,
        ]}
      >
        {/* Cruz Central */}
        <View style={styles.crossHairVertical} />
        <View style={styles.crossHairHorizontal} />

        {/* A Bolinha que se move */}
        <View
          style={[
            styles.bubble,
            {
              transform: [
                { translateX: leftPosition },
                { translateY: topPosition },
              ],
              backgroundColor: isLevel ? "#4caf50" : "#ff4757",
            },
          ]}
        />
      </View>

      {/* Dados numéricos */}
      <View style={styles.dataContainer}>
        <Text style={styles.dataText}>X: {x.toFixed(2)}</Text>
        <Text style={styles.dataText}>Y: {y.toFixed(2)}</Text>
      </View>

      {erro && <Text style={styles.erro}>{erro}</Text>}

      {Platform.OS === "web" && (
        <Text style={styles.webWarning}>
          * Simulação na Web pode não ser precisa
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F2F4F8",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: "#666",
    marginBottom: 40,
  },
  // O Alvo (Círculo Grande)
  outerCircle: {
    width: 300,
    height: 300,
    borderRadius: 150,
    borderWidth: 5,
    backgroundColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 40,
    overflow: "hidden", // Impede a bolinha de sair visualmente
    elevation: 5, // Sombra
  },
  borderGreen: { borderColor: "#4caf50" },
  borderRed: { borderColor: "#ff4757" },

  // A Bolinha (Nível)
  bubble: {
    width: CIRCLE_SIZE,
    height: CIRCLE_SIZE,
    borderRadius: CIRCLE_SIZE / 2,
    position: "absolute",
    // Sombra na bolinha para parecer 3D
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  // Linhas de mira (Crosshair)
  crossHairVertical: {
    position: "absolute",
    width: 2,
    height: "100%",
    backgroundColor: "#eee",
  },
  crossHairHorizontal: {
    position: "absolute",
    width: "100%",
    height: 2,
    backgroundColor: "#eee",
  },
  // Dados
  dataContainer: {
    flexDirection: "row",
    gap: 20,
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 10,
    elevation: 2,
  },
  dataText: {
    fontSize: 18,
    fontFamily: Platform.OS === "ios" ? "Courier" : "monospace", // Fonte monoespaçada para números não pularem
    fontWeight: "bold",
    color: "#555",
  },
  erro: {
    color: "red",
    marginTop: 20,
  },
  webWarning: {
    marginTop: 20,
    color: "#999",
    fontStyle: "italic",
  },
});
