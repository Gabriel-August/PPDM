import "react-native-gesture-handler";
import React, { useRef } from "react";
import {
  StyleSheet,
  View,
  Text,
  Animated,
  Dimensions,
  Platform,
} from "react-native";
import {
  PanGestureHandler,
  GestureHandlerRootView,
  State,
} from "react-native-gesture-handler";
import { MaterialIcons } from "@expo/vector-icons";

const { width, height } = Dimensions.get("window");
const CIRCLE_SIZE = 80;

export default function ArrastarDrag() {
  // Valores animados para X e Y
  const translateX = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(1)).current;

  // Guardamos a última posição para continuar de onde parou
  const lastOffset = useRef({ x: 0, y: 0 }).current;

  // Evento que segue o dedo
  const onGestureEvent = Animated.event(
    [
      {
        nativeEvent: {
          translationX: translateX,
          translationY: translateY,
        },
      },
    ],
    { useNativeDriver: true }
  );

  const onHandlerStateChange = (event) => {
    // 1. Quando TOCA no objeto (Began)
    if (event.nativeEvent.state === State.BEGAN) {
      // Aumenta um pouco para dar feedback que "pegou"
      Animated.spring(scale, {
        toValue: 1.2,
        useNativeDriver: true,
      }).start();
    }

    // 2. Quando SOLTA o objeto (End/Fail/Cancel)
    if (event.nativeEvent.oldState === State.ACTIVE) {
      const { translationX, translationY } = event.nativeEvent;

      // Calcula a nova posição somando o que já tinha + o que andou
      let newX = lastOffset.x + translationX;
      let newY = lastOffset.y + translationY;

      // --- LIMITES DA TELA (Clamping) ---
      // Impede que o círculo saia da tela (Cálculo aproximado baseado no centro)
      // Limite horizontal
      const limitX = width / 2 - CIRCLE_SIZE / 2;
      if (newX > limitX) newX = limitX;
      if (newX < -limitX) newX = -limitX;

      // Limite vertical
      const limitY = height / 2 - CIRCLE_SIZE / 2 - 50; // -50 de margem segura
      if (newY > limitY) newY = limitY;
      if (newY < -limitY) newY = -limitY;

      // Atualiza o offset (ponto zero) para a nova posição válida
      translateX.setOffset(newX);
      translateX.setValue(0);
      translateY.setOffset(newY);
      translateY.setValue(0);

      // Salva na referência
      lastOffset.x = newX;
      lastOffset.y = newY;

      // Volta ao tamanho normal (com efeito elástico)
      Animated.spring(scale, {
        toValue: 1,
        friction: 5,
        useNativeDriver: true,
      }).start();
    }
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <Text style={styles.title}>Arraste e Solte</Text>
        <Text style={styles.subtitle}>Tente jogar o círculo nas bordas</Text>

        <PanGestureHandler
          onGestureEvent={onGestureEvent}
          onHandlerStateChange={onHandlerStateChange}
        >
          <Animated.View
            style={[
              styles.circle,
              {
                transform: [
                  { translateX: translateX },
                  { translateY: translateY },
                  { scale: scale }, // Adiciona o efeito de zoom
                ],
              },
            ]}
          >
            <MaterialIcons name="drag-indicator" size={40} color="#fff" />
          </Animated.View>
        </PanGestureHandler>
      </View>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F4F8",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    position: "absolute",
    top: 60,
  },
  subtitle: {
    fontSize: 16,
    color: "#888",
    position: "absolute",
    top: 95,
  },
  circle: {
    width: CIRCLE_SIZE,
    height: CIRCLE_SIZE,
    borderRadius: CIRCLE_SIZE / 2,
    backgroundColor: "#2979FF",
    alignItems: "center",
    justifyContent: "center",
    // Sombras para dar profundidade
    elevation: 10,
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 4 },
    zIndex: 999,
  },
});
