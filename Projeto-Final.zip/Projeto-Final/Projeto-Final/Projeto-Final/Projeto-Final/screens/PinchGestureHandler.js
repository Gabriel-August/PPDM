import "react-native-gesture-handler";
import React, { useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Image,
  Dimensions,
} from "react-native";
import {
  PinchGestureHandler,
  GestureHandlerRootView,
  State,
} from "react-native-gesture-handler";
import { MaterialIcons } from "@expo/vector-icons";

const { width } = Dimensions.get("window");

export default function PinchScreen() {
  const scale = useRef(new Animated.Value(1)).current;

  // Evento que conecta o movimento dos dedos ao valor da escala
  const onPinchEvent = Animated.event([{ nativeEvent: { scale: scale } }], {
    useNativeDriver: true,
  });

  // Função mágica: Detecta quando você SOLTA os dedos
  const onPinchStateChange = (event) => {
    if (event.nativeEvent.oldState === State.ACTIVE) {
      // Efeito Elástico: Volta para o tamanho 1 (original)
      Animated.spring(scale, {
        toValue: 1,
        useNativeDriver: true,
        bounciness: 10, // Define o quanto ela "quica" ao voltar
      }).start();
    }
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <View style={styles.header}>
          <MaterialIcons name="zoom-in" size={40} color="#447cec" />
          <Text style={styles.title}>Zoom Elástico</Text>
          <Text style={styles.subtitle}>Faça pinça para ampliar e solte</Text>
        </View>

        <PinchGestureHandler
          onGestureEvent={onPinchEvent}
          onHandlerStateChange={onPinchStateChange}
        >
          <Animated.View
            style={[
              styles.card,
              {
                transform: [
                  { scale: scale },
                  { perspective: 1000 }, // Ajuda na qualidade da animação 3D
                ],
                zIndex: 1, // Garante que fique por cima ao ampliar
              },
            ]}
          >
            {/* Moldura da Foto */}
            <View style={styles.imageContainer}>
              <Image
                //  imagem local aqui:
                source={require("../assets/blocoDeGelo.jpg")}
                style={styles.image}
                resizeMode="cover"
              />
            </View>

            {/* Legenda da Foto */}
            <View style={styles.captionContainer}>
              <Text style={styles.captionTitle}>Bloco de Gelo</Text>
              <Text style={styles.captionSubtitle}>
                Detalhes em Alta Resolução
              </Text>
            </View>
          </Animated.View>
        </PinchGestureHandler>

        <Text style={styles.hint}>Tente dar zoom máximo!</Text>
      </View>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F4F8",
    justifyContent: "center",
    alignItems: "center",
  },
  header: {
    alignItems: "center",
    marginBottom: 40,
    marginTop: -50, // Sobe um pouco o texto para dar espaço
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginTop: 5,
  },
  subtitle: {
    fontSize: 16,
    color: "#888",
  },
  // O Cartão Estilo Polaroid
  card: {
    width: width * 0.8, // 80% da largura da tela
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 10,
    // Sombras poderosas
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
  },
  imageContainer: {
    width: "100%",
    height: 300, // Altura fixa para a foto
    borderRadius: 15,
    overflow: "hidden", // Corta a imagem se passar das bordas
    backgroundColor: "#eee",
  },
  image: {
    width: "100%",
    height: "100%",
  },
  captionContainer: {
    paddingVertical: 15,
    paddingHorizontal: 10,
  },
  captionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
  },
  captionSubtitle: {
    fontSize: 14,
    color: "#666",
    marginTop: 2,
  },
  hint: {
    position: "absolute",
    bottom: 50,
    color: "#aaa",
    fontStyle: "italic",
  },
});
