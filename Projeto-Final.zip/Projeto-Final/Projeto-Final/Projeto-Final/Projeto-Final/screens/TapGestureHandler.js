import "react-native-gesture-handler";
import React, { useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
} from "react-native";
import {
  TapGestureHandler,
  State,
  GestureHandlerRootView,
} from "react-native-gesture-handler";
import { MaterialIcons } from "@expo/vector-icons"; // Ícone para o botão de reset

export default function TapScreen() {
  const [count, setCount] = useState(0);

  // Valor animado para o efeito de escala (pulsar)
  const scale = useRef(new Animated.Value(1)).current;

  const onSingleTap = () => {
    // 1. Atualiza o contador
    setCount((currentCount) => currentCount + 1);

    // 2. Dispara a Animação (Encolhe rápido e volta elástico)
    Animated.sequence([
      Animated.timing(scale, {
        toValue: 0.9, // Diminui para 90% do tamanho
        duration: 50,
        useNativeDriver: true,
      }),
      Animated.spring(scale, {
        toValue: 1, // Volta ao tamanho normal com efeito de mola
        friction: 3, // Quão "saltitante" é a mola
        useNativeDriver: true,
      }),
    ]).start();
  };

  const onReset = () => {
    setCount(0);
  };

  return (
    // IMPORTANTE: GestureHandlerRootView é obrigatório para Android
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <Text style={styles.title}>Contador de Toques</Text>

        {/* Área do Gesto */}
        <TapGestureHandler onActivated={onSingleTap}>
          <Animated.View
            style={[
              styles.tapCircle,
              { transform: [{ scale: scale }] }, // Aplica a animação aqui
            ]}
          >
            <Text style={styles.countNumber}>{count}</Text>
            <Text style={styles.tapLabel}>TOQUE AQUI</Text>
          </Animated.View>
        </TapGestureHandler>

        {/* Botão de Reset Customizado */}
        <TouchableOpacity style={styles.resetButton} onPress={onReset}>
          <MaterialIcons name="refresh" size={24} color="#fff" />
          <Text style={styles.resetText}>Zerar Contagem</Text>
        </TouchableOpacity>
      </View>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F4F8",
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 40,
  },
  // O Círculo Grande
  tapCircle: {
    width: 200,
    height: 200,
    borderRadius: 100, // Círculo perfeito
    backgroundColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
    // Sombras
    elevation: 10,
    shadowColor: "#447cec",
    shadowOpacity: 0.3,
    shadowRadius: 15,
    shadowOffset: { width: 0, height: 10 },
    borderWidth: 4,
    borderColor: "#447cec",
  },
  countNumber: {
    fontSize: 60,
    fontWeight: "bold",
    color: "#447cec",
  },
  tapLabel: {
    fontSize: 14,
    color: "#aaa",
    marginTop: 5,
    fontWeight: "bold",
    letterSpacing: 1,
  },
  // Botão Reset
  resetButton: {
    flexDirection: "row",
    backgroundColor: "#ff4757",
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 30,
    alignItems: "center",
    marginTop: 50,
    gap: 10, // Espaço entre ícone e texto
    elevation: 3,
  },
  resetText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});
