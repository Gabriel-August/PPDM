import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  Alert,
} from "react-native";
import { MaterialIcons, FontAwesome5 } from "@expo/vector-icons";

export default function PerfilScreen() {
  const handleLogout = () => {
    Alert.alert("Sair", "Você foi desconectado com sucesso!");
  };

  const handleEdit = () => {
    Alert.alert("Editar", "Aqui abriria a tela de edição de perfil.");
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* --- CABEÇALHO DO PERFIL --- */}
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <Image
            // Imagem perfil
            source={{ uri: "https://github.com/shadcn.png" }}
            style={styles.avatar}
          />
          <TouchableOpacity style={styles.editIcon} onPress={handleEdit}>
            <MaterialIcons name="edit" size={18} color="#fff" />
          </TouchableOpacity>
        </View>

        <Text style={styles.name}>Gabriel Augusto</Text>
        <Text style={styles.email}>estudante@senai.br</Text>
        <Text style={styles.role}>Desenvolvimento de Sistemas</Text>
      </View>

      {/* --- ESTATÍSTICAS --- */}
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>12</Text>
          <Text style={styles.statLabel}>Projetos</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>5</Text>
          <Text style={styles.statLabel}>Concluídos</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>4.8</Text>
          <Text style={styles.statLabel}>Avaliação</Text>
        </View>
      </View>

      {/* --- MENU DE OPÇÕES --- */}
      <View style={styles.menuContainer}>
        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => Alert.alert("Dados Pessoais")}
        >
          <View style={styles.menuIconBox}>
            <FontAwesome5 name="user" size={20} color="#447cec" />
          </View>
          <Text style={styles.menuText}>Dados Pessoais</Text>
          <MaterialIcons name="chevron-right" size={24} color="#ccc" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => Alert.alert("Configurações")}
        >
          <View style={styles.menuIconBox}>
            <FontAwesome5 name="cog" size={20} color="#447cec" />
          </View>
          <Text style={styles.menuText}>Configurações</Text>
          <MaterialIcons name="chevron-right" size={24} color="#ccc" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => Alert.alert("Privacidade")}
        >
          <View style={styles.menuIconBox}>
            <FontAwesome5 name="lock" size={20} color="#447cec" />
          </View>
          <Text style={styles.menuText}>Privacidade e Segurança</Text>
          <MaterialIcons name="chevron-right" size={24} color="#ccc" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => Alert.alert("Ajuda")}
        >
          <View style={styles.menuIconBox}>
            <FontAwesome5 name="question-circle" size={20} color="#447cec" />
          </View>
          <Text style={styles.menuText}>Ajuda e Suporte</Text>
          <MaterialIcons name="chevron-right" size={24} color="#ccc" />
        </TouchableOpacity>
      </View>

      {/* --- BOTÃO DE SAIR --- */}
      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <MaterialIcons name="logout" size={24} color="#fff" />
        <Text style={styles.logoutText}>Sair da Conta</Text>
      </TouchableOpacity>

      <Text style={styles.versionText}>Versão 1.0.0</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: "#F2F4F8",
    alignItems: "center",
    paddingBottom: 40,
  },
  // Cabeçalho
  header: {
    width: "100%",
    backgroundColor: "#fff",
    alignItems: "center",
    paddingVertical: 30,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    elevation: 5,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 10,
    marginBottom: 20,
  },
  avatarContainer: {
    position: "relative",
    marginBottom: 15,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 4,
    borderColor: "#447cec",
  },
  editIcon: {
    position: "absolute",
    bottom: 0,
    right: 0,
    backgroundColor: "#447cec",
    padding: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: "#fff",
  },
  name: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#333",
  },
  email: {
    fontSize: 14,
    color: "#666",
    marginBottom: 5,
  },
  role: {
    fontSize: 14,
    color: "#447cec",
    fontWeight: "600",
    backgroundColor: "#EDF2FF",
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 15,
  },
  // Estatísticas
  statsContainer: {
    flexDirection: "row",
    backgroundColor: "#fff",
    width: "90%",
    padding: 15,
    borderRadius: 15,
    justifyContent: "space-around",
    alignItems: "center",
    marginBottom: 20,
    elevation: 2,
  },
  statItem: {
    alignItems: "center",
  },
  statNumber: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
  },
  statLabel: {
    fontSize: 12,
    color: "#888",
  },
  statDivider: {
    width: 1,
    height: "80%",
    backgroundColor: "#eee",
  },
  // Menu
  menuContainer: {
    width: "90%",
    backgroundColor: "#fff",
    borderRadius: 15,
    padding: 10,
    marginBottom: 20,
    elevation: 2,
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  menuIconBox: {
    width: 35,
    height: 35,
    backgroundColor: "#F2F4F8",
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },
  menuText: {
    flex: 1,
    fontSize: 16,
    color: "#333",
    fontWeight: "500",
  },
  // Botão Sair
  logoutButton: {
    flexDirection: "row",
    backgroundColor: "#ff4757",
    width: "90%",
    padding: 15,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    gap: 10,
    elevation: 3,
  },
  logoutText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  versionText: {
    marginTop: 20,
    color: "#aaa",
    fontSize: 12,
  },
});
