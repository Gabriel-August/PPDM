import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, ScrollView } from "react-native";
import Header from "./src/components/Header";
import Footer from "./src/components/Footer";
import Main from "./src/components/Main";
import Menu from "./src/components/Menu";
import ConfigScreen from "./screens/ConfigScreen";
import HomeScreen from "./screens/HomeScreen";
import PerfilScreen from "./screens/PerfilScreen";
import TapGestureHandler from "./screens/TapGestureHandler";
import RotationGestureHandler from "./screens/RotationGestureHandler";
import PinchGestureHandler from "./screens/PinchGestureHandler";
import LongPressGestureHandler from "./screens/LongPressGestureHandler";
import DragAndDrop from "./screens/ArrastarDrag";
import Acelerometro from "./screens/Acelerometro";
import Som from "./screens/Som";
import MapaScreens from "./screens/MapaScreen";
import GpsScreens from "./screens/GpsScreen";
import CameraScreen from "./screens/CameraScreen";
import ListaScreen from "./screens/ListaScreen";
import WifiScreen from "./screens/WifiScreen";
import { NavigationContainer } from "@react-navigation/native";

import { createDrawerNavigator } from "@react-navigation/drawer";

const Drawer = createDrawerNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: "Home" }}
        />
        <Drawer.Screen
          name="Configuração"
          component={ConfigScreen}
          options={{ title: "Config" }}
        />
        <Drawer.Screen
          name="Perfil"
          component={PerfilScreen}
          options={{ title: "Perfil" }}
        />
        <Drawer.Screen
          name="TapGestureHandler"
          component={TapGestureHandler}
          options={{ title: "Contador de Toques" }}
        />
        <Drawer.Screen
          name="RotationGestureHandler"
          component={RotationGestureHandler}
          options={{ title: "Rotação com os Dedos" }}
        />
        <Drawer.Screen
          name="PinchGestureHandler"
          component={PinchGestureHandler}
          options={{ title: "Zoom +" }}
        />
        <Drawer.Screen
          name="LongPressGestureHandler"
          component={LongPressGestureHandler}
          options={{ title: "Toque Longo" }}
        />
        <Drawer.Screen
          name="Acelerometro"
          component={Acelerometro}
          options={{ title: "Acelerometro" }}
        />
        <Drawer.Screen
          name="ArrastarDrag"
          component={DragAndDrop}
          options={{ title: "Arrastar" }}
        />
        <Drawer.Screen name="Som" component={Som} options={{ title: "Som" }} />
        <Drawer.Screen
          name="MapaScreens"
          component={MapaScreens}
          options={{ title: "Mapa" }}
        />
        <Drawer.Screen
          name="GpsScreens"
          component={GpsScreens}
          options={{ title: "Gps" }}
        />
        <Drawer.Screen
          name="CameraScreens"
          component={CameraScreen}
          options={{ title: "Camera" }}
        />
        <Drawer.Screen
          name="ListaScreen"
          component={ListaScreen}
          options={{ title: "Percistencia" }}
        />
        <Drawer.Screen
          name="WifiScreen"
          component={WifiScreen}
          options={{ title: "Wifi" }}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
