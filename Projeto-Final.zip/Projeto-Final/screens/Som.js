import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Button } from "react-native";
import { Audio } from "expo-av";
import React, { useEffect, useState } from "react";

export default function App() {
  const [sound, setSound] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLooping, setIsLooping] = useState(false);

  async function playSound() {
    if (!sound) {
      const { sound: newSound } = await Audio.Sound.createAsync(
        require("./assets/Dobrado 220.mp3"),
        { isLooping }
      );
      setSound(newSound);
      await newSound.playAsync();
      setIsPlaying(true);
    } else if (!isPlaying) {
      await sound.playAsync();
      setIsPlaying(true);
    }
  }

  async function pauseSound() {
    if (sound) {
      await sound.pauseAsync();
      setIsPlaying(false);
    }
  }

  async function toggleLoop() {
    if (sound) {
      await sound.setIsLoopingAsync(!isLooping);
    }
    setIsLooping((prev) => !prev);
  }

  async function restartSound() {
    if (sound) {
      await sound.stopAsync();
      await sound.setPositionAsync(0);
      await sound.playAsync();
      setIsPlaying(true);
    }
  }

  useEffect(() => {
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, [sound]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Reprodutor de Áudio</Text>
      <Button
        title={isPlaying ? "Pausar" : "Tocar"}
        onPress={isPlaying ? pauseSound : playSound}
      />
      <Button
        title={isLooping ? "Repetir: Ligado" : "Repetir: Desligado"}
        onPress={toggleLoop}
        color={isLooping ? "#4caf50" : "#757575"}
      />
      <Button title="Repetir Agora" onPress={restartSound} color="#2196f3" />
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
});
