import "react-native-gesture-handler";
import React, { useState } from "react";
import { View, Text, StyleSheet, Animated } from "react-native";
import { PinchGestureHandler } from "react-native-gesture-handler";
import { Feather } from "@expo/vector-icons";

export default function App() {
  const [scale] = useState(new Animated.Value(1));

  const onPinchEvent = Animated.event([{ nativeEvent: { scale: scale } }], {
    useNativeDriver: true,
  });

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gesto de Pinça (Pinch)</Text>
      <Text style={styles.subtitle}>
        Use dois dedos para ampliar ou reduzir o cartão.
      </Text>

      {/* O {" "} que estava aqui foi removido */}
      <PinchGestureHandler onGestureEvent={onPinchEvent}>
        <Animated.View
          style={[
            styles.card,
            {
              transform: [{ scale }],
            },
          ]}
        >
          <Feather name="image" size={60} color="#1E90FF" />
          {/* O {" "} que estava aqui foi removido */}
        </Animated.View>
        {/* O {" "} que estava aqui foi removido */}
      </PinchGestureHandler>
      {/* O {" "} que estava aqui foi removido */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f4f4f8",
  },
  title: {
    fontSize: 24,
    fontWeight: "500",
    color: "#333",
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: "#555",
    marginBottom: 40,
    textAlign: "center",
    paddingHorizontal: 20,
  },
  card: {
    width: 150,
    height: 150,
    backgroundColor: "#fff",
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
    // --- Sombra para dar profundidade ---
    // Sombra (iOS)
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    // Sombra (Android)
    elevation: 5,
  },
});
